'use strict';

module.exports = require('./user_handler.js'); 
module.exports = require('./role_handler.js'); 








