'use strict';

module.exports = require('./user_handler.js'); 








